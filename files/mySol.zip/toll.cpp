#include <iostream>
using namespace std;

int booth[20][2]; //0: soldiers, 1: toll
int n, minCost;

void getMin(int index, int zero, int one, int two, int cost){
    if(cost >= minCost)return;
    if(index == n){
        minCost = minCost > cost ? cost : minCost;
        return;
    }
    //pay the toll
    getMin(index + 1, zero, one, two, cost + booth[index][1]);
    //pay double toll and get soldiers
    getMin(index + 1, zero + booth[index][0], one, two, 2 * booth[index][1] + cost);
    //battle if possible
    if(zero + one + two >= booth[index][0]){
        int toDie = booth[index][0];
        //first eliminate soldiers with two battles
        if(two >= toDie){
            two-=toDie;
            toDie = 0;
        }
        else{
            toDie-=two;
            two = 0;
        }
        //remaining from one battle soldiers
        if(one >= toDie){
            one-=toDie;
            toDie = 0;
        }
        else{
            toDie-=one;
            one = 0;
        }
        //last from soldiers with zero battles
        zero -= toDie;
        getMin(index+1, 0, zero, one,cost);
    }
    return;
}

int main() {
	int t;
	cin >> t;
	for(int c = 0; c < t; c++){
	    cin >> n;
	    for(int i = 0; i < n; i++){
	        cin >> booth[i][0] >> booth[i][1];
	    }
	    minCost = 999999;
	    getMin(0, 0, 0, 0, 0);
	    cout << "#" << c+1 << " " << minCost << endl;
	}
	return 0;
}