#include <iostream>
using namespace std;

int arr[12], n;
int dp[13][13];
int getMax(int left, int right){
	int curr = 0, maxCoins = 0;
	if(dp[left][right])return dp[left][right];
	for(int i = left + 1; i <= right - 1; i++){
		curr = getMax(left, i) + getMax(i, right);
		if(left == 0 && right == n + 1){
			//main case
			curr += arr[i];
		}
		else{
			curr += arr[left] * arr[right];
		}
		if(curr > maxCoins)maxCoins = curr;
	}
	return dp[left][right] = maxCoins;
}

int main(){
	int t;
	cin >> t;
	for(int c = 0; c < t; c++){
		cin >> n;
		for(int i = 1; i <= n; i++){
			cin >> arr[i];
		}
		arr[0] = 1;
		arr[n + 1] = 1;
		for(int i = 0; i <= 12; i++){
			for(int j = 0; j <= 12; j++){
				dp[i][j] = 0;
			}
		}
		cout << getMax(0, n + 1) << endl;
	}
	system("pause");
	return 0;
}