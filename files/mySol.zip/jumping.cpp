#include <iostream>
using namespace std;
int n,m, arr[50][50], visited[50][50];

int reachable(int i, int j, int jump){
    visited[i][j] = 1;
    if(arr[i][j] == 3)return 1;
    int reached = 0;
    if(j-1 >= 0 && arr[i][j-1] && !visited[i][j-1]){//left
        reached |= reachable(i, j-1, jump);
    }
    if(j+1 < m && arr[i][j+1] && !visited[i][j+1]){//right
        reached |= reachable(i, j+1, jump);
    }
    for(int k = 1; k <= jump; k++){
        //climb up
        if(i-k >= 0 && arr[i-k][j] && !visited[i-k][j]){
            reached |= reachable(i-k, j, jump);
        }
        //climb down
        if(i+k < n && arr[i+k][j] && !visited[i+k][j]){
            reached |= reachable(i+k, j, jump);
        }
    }
    return reached;
}

int main() {
	int t, jump = 0, x, y;
	cin >> t;
	for(int c = 0; c < t; c++){
	    cin >> n >> m;
	    for(int i = 0; i < n; i++){
	        for(int j = 0; j < m; j++){
	            cin >> arr[i][j];
	            if(arr[i][j] == 2){
	                x = i;
	                y = j;
	            }
	        }
	    }
	    for(jump = 1; jump <= 50; jump++){
	        for(int i = 0; i < n; i++){
	            for(int j = 0; j < m; j++){
	                visited[i][j] = 0;
	            }
	        }
	        if(reachable(x, y, jump))break;
	    }
	    cout << jump << endl;
	}
	return 0;
}