#include <iostream>
#include <cstring>
using namespace std;

int a[16][16];//assuming max input size of 15*15 for simplicity, 3 choices after self is chosen

void setZero(int** arr, int h, int w){
    for(int i = 0; i < h; i++){
        for(int j= 0; j < w; j++)arr[i][j] = 0;
    }
}

int** getClone(int** arr, int h, int w){
    int** out = new int*[h];
    for(int k = 0; k < h; k++)out[k] = new int[w];
    for(int i = 0; i < h; i++){
        for(int j = 0; j < w; j++){
            out[i][j] = arr[i][j];
        }
    }
    return out;
}

int getMaxCoverage(int x, int y, int count, int** chosen, int h, int w){
    if(x >= h || y >= w || x < 0 || y < 0)return -999999;
    if(chosen[x][y] == 1)return -999999;//case not allowed, will not be accepted in max
    chosen[x][y] = 1; //choice is made
    count--;
    //if(dp[i][j][count] != 0)return dp[i][j][count]; //already calculated
    if(count == 0)return a[x][y]; //current cell was the last to be chosen
    int curr[6]; //6 possible choices
    if(y%2){
        //odd column
        curr[0] = getMaxCoverage(x-1, y, count, getClone(chosen,h,w),h ,w);//top
        curr[1] = getMaxCoverage(x-1, y+1, count, getClone(chosen,h,w),h ,w);//top-r
        curr[2] = getMaxCoverage(x, y+1, count, getClone(chosen,h,w),h ,w);//r
        curr[3] = getMaxCoverage(x+1, y, count, getClone(chosen,h,w),h ,w);//bottom
        curr[4] = getMaxCoverage(x, y-1, count, getClone(chosen,h,w),h ,w);//l
        curr[5] = getMaxCoverage(x-1, y-1, count, getClone(chosen,h,w),h ,w);//top-l
    }
    else{
        //even column
        curr[0] = getMaxCoverage(x-1, y, count, getClone(chosen,h,w),h ,w);//top
        curr[1] = getMaxCoverage(x+1, y+1, count, getClone(chosen,h,w),h ,w);//bottom-r
        curr[2] = getMaxCoverage(x, y+1, count, getClone(chosen,h,w),h ,w);//r
        curr[3] = getMaxCoverage(x+1, y, count, getClone(chosen,h,w),h ,w);//bottom
        curr[4] = getMaxCoverage(x, y-1, count, getClone(chosen,h,w),h ,w);//l
        curr[5] = getMaxCoverage(x+1, y-1, count, getClone(chosen,h,w),h ,w);//bottom-l
    }
    int currMax = 0;
    for(int k = 0; k < 6; k++){
        if(curr[k] > currMax) currMax = curr[k];
    }
    return currMax + a[x][y];
} 


int main() {
	int t, i, j, h, w;
	cin>>t;
	for(int c = 0; c < t; c++){
	    cin >> h;
	    cin >> w;
	    for(i = 0; i < h; i++){
	        for(j = 0; j < w; j++){
	            cin >> a[i][j];
	            //for(int k = 0; k < 3; k++)dp[i][j][k] = 0;//reset from prev iterations
	            
	        }
	    }
	    int maxCoverage = -1;
	    int currCoverage = 0;
	    int** chosen = new int*[h];
	    for(int k = 0; k < h; k++)chosen[k] = new int[w];
	    // h*w ways to choose starting point, many have overlapping solution
	    for(i = 0; i < h; i++){
	        for(j = 0; j < w; j++){
	            setZero(chosen, h, w);
	            //chosen[i][j] = 1;
	            currCoverage = getMaxCoverage(i, j, 3, getClone(chosen,h,w), h, w);
	            if(currCoverage > maxCoverage)maxCoverage = currCoverage;
	        }
	    }
	    cout << maxCoverage << endl;
	}
	return 0;
}