#include <iostream>
using namespace std;
int arr[20]; // cars(1..n) + 2 stations(0,n+1)
int minSteps;

void getMinSteps(int loc, int type, int qty, int n, int dir, int left, int steps){
	if(!left){
		if(steps < minSteps)minSteps = steps-1;
		return;
	}
	if(steps > minSteps)return;
	if(loc > n+1 || loc < 0){
		return;
	}
	if(loc == 0){
		getMinSteps(1, 1, 2, n, 1, left, steps + 1); //refill petrol and continue
		return;
	}
	if(loc == n + 1){
		getMinSteps(n, 2, 2, n, -1, left, steps + 1); //refill diesel and continue
		return;
	}
	if(type != arr[loc]){
		getMinSteps(loc+dir, type, qty, n, dir, left, steps + 1);
		return;
	}
	if(type == arr[loc]){
		//fuel now
		int temp = arr[loc];
		arr[loc] = -1;
		if(qty == 1){
			//send to either of the stations
			getMinSteps(0, 0, 0, n, 0, left-1, steps + loc);
			getMinSteps(n+1, 0, 0, n, 0, left-1, n - loc + steps);
			
		}
		else if(qty == 2){
			getMinSteps(loc+1, type, qty-1, n, 1, left-1, steps + 1);
			getMinSteps(loc-1, type, qty-1, n, -1, left-1, steps + 1);
		}
		arr[loc] = temp;
		//do not fuel now
		getMinSteps(loc+dir, type, qty, n, dir, left, steps + 1);
	}
}

int main(){
	int t, n;
	cin >> t;
	for(int c = 0; c < t; c++){
		cin >> n;
		for(int i = 1; i <= n; i++)cin >> arr[i];
		minSteps = 9999999;
		getMinSteps(0, 0, 0, n, 0,n, 0);
		cout << minSteps << endl;
	}
	return 0;
}