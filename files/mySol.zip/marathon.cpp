#include <iostream>
using namespace std;
int profile[5][2];
int E, D;
int dp[41][1000];//stores time taken
int main() {
	int t;
	float min, sec, en;
	cin >> t;
	for(int c = 0; c < t; c++){
	    cin >> E >> D;
	    for(int i = 0; i < 5; i++){
	        cin >> min >> sec >> profile[i][1];
	        profile[i][0] = min*60 + sec;//store time in sec
	    }
	    for(int i = 0; i <= D; i++){
	        for(int j = 0; j <= E; j++){
	                dp[i][j] = 0;
	        }
	    }
	    int curr, min;
	    for(int d = 1; d <= D; d++){
	        for(int e = 0; e <= E; e++){
	            min = curr = 999999;
	            for(int i = 0; i < 5; i++){
	                if(e-profile[i][1] >= 0){
	                    curr = profile[i][0] + dp[d-1][e-profile[i][1]]; 
	                }
	                if(curr < min)min = curr;
	            }
	            dp[d][e] = min;
	        }
	    }
	    int ans = 999999;
	    for(int i = 1; i <= E; i++){
	        if(dp[D][i] < ans)ans = dp[D][i];
	    }
	    cout << ans/60 << endl;
	}
	return 0;
}