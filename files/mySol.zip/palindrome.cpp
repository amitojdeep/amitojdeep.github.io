#include<iostream>

using namespace std;

int count1;
bool palindrom(int ans[100],int j){
  for(int i=0;i<j/2;i++){
    if(ans[i]!=ans[j-i-1])return false;
  }
  return true;
}
void permute(int ans[100],int value,int point,int* count, int * array,int n,int j){//j is current location in ans
    
  if(point==4){
    for(int i=0;i<n;i++){
      if(count[i]==0){return;}//one of the digits is unused
    }
    if(palindrom(ans,j))count1++;//just check for symmetry and increase global counter
    return;
  }
  for(int i=0;i<n;i++){
    if(count[i]!=2)//digit is usable
    {
      int value1=value*10+array[i];
      count[i]++;
      ans[j]=array[i];
      if(value1<256){permute(ans,0,point+1,count,array,n,j+1); }//value1 is valid 8 bit number, go to next 8 bit number
      if(value1!=0 && value1<256)permute(ans,value1,point,count,array,n,j+1);//stay in same 8 bit number
      count[i]--;
    }
    
  }
}
void main(){
  int test;
  //freopen("test.txt", "r", stdin);
  cin>>test;
  cout << test;
  while(test--){
    count1=0;
    int ans[100];
    for(int i=0;i<100;i++){ans[i]=0;}
    int n;
    cin>>n;
    int arr[100];
    int count[100];
    for(int i=0;i<n;i++){cin>>arr[i];count[i]=0;}
    permute(ans,0,0,count,arr,n,0);
    cout<<count1<<endl;
  }
}