#include <iostream>
using namespace std;

int a[13][5], b[13][5];

void detonate(int row){
    //start detonating from 4 rows above k and go till k
    for(int k = row; k >= row-4 && k>= 0; k--){
        for(int j = 0; j < 5; j++){
            if(a[k][j] == 2)a[k][j] = 0; //detonate
        }
    }
}

void undetonate(int row){
    for(int k = row; k >= row-4 && k >= 0; k--){
        for(int j = 0; j < 5; j++){
            a[k][j] = b[k][j]; //restore
        }
    }
}

void getMaxCoins(int pos, int coins, int n, int &currMax){
    if(pos < 0 || pos > 4 || coins < 0)return;
    //look in row above
    if(a[n-1][pos] == 2)coins-=1;
    else if(a[n-1][pos] == 1)coins+=1;
    if(n == 1){
        if(coins > currMax)currMax = coins;
        return;
    }
    getMaxCoins(pos, coins, n-1, currMax); //no change
    getMaxCoins(pos-1, coins, n-1, currMax);//left
    getMaxCoins(pos+1, coins, n-1, currMax);//right
}



int main() {
	int t, n, maxCoins, coins;
	cin >> t;
	for(int c = 0; c < t; c++){
	    cin >> n;
	    //take input
	    for(int i = 0; i < n; i++){
	        for(int j = 0; j < 5; j++){
	            cin >> a[i][j];
	            b[i][j] = a[i][j]; //backup
	        }
	    }
	    for(int j = 0; j < 5; j++)a[n][j] = 0; //fill bottom row
	    a[n][2] = 3; //place the plane
	    //consider detonation in one row at a time
	    maxCoins = -1;
	    for(int i = n - 1; i > 0; i--){
	        detonate(i);
	        coins = -1;
	        getMaxCoins(2, 0, n, coins);
	        if(coins > maxCoins)maxCoins = coins;
	        undetonate(i);
	    }
	    if(maxCoins < 0)cout << -1 << endl;
	    else cout << maxCoins << endl;
	}
	return 0;
}