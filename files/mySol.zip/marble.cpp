#include<iostream>
using namespace std;
int arr[5][5];
int temp[5][5];

int direction[5][4] = {
	{ 2, 0, 3, 1 }, { 3, 0, 1, 2 }, { 1, 3, 0, 2 }, { 1, 2, 3, 0 }, { 1, 0, 3, 2 } }; //new direction corresponding to current as index
//0 = left, 1 = right, 2 = up, 3 = down

int marble(int i,int j,int arr[5][5],int n,int m,int dir)
{
  int nochange=0;
  int ans=0;
  while(nochange<6)
  {
      //looping
    if(i==-1)
      i=n-1;
    if(j==-1)
    j=m-1;
    if(i==n)
    i=0;
    if(j==m)
    j=0;
    //move no reflection
    if(arr[i][j]==0)
    {
      nochange=nochange+1;
      if(dir==0)
      j=j-1;
      else if(dir==1)
      j=j+1;
      else if(dir==2)
      i=i-1;
      else if(dir==3)
      i=i+1;
    }
    //reflect
    else
    {
      nochange=0;
      int temp=arr[i][j]/10; //type
      int temp2=arr[i][j]%10;//health
      if(direction[temp-1][dir]==0) //lookup next dir
      {
        arr[i][j]=temp*10+temp2-1; //health dec
        j=j-1;
        dir=0;
        //kill on 0 health and increment ans
        if(temp2-1==0)
          {arr[i][j+1]=0;
          ans++;
          }
      }
      else if(direction[temp-1][dir]==1)
      {
        arr[i][j]=temp*10+temp2-1;
        j=j+1;
        dir=1;
        if(temp2-1==0)
          {arr[i][j-1]=0;
          ans++;
          }
      }
      else if(direction[temp-1][dir]==2)
      {
        arr[i][j]=temp*10+temp2-1;
        i=i-1;
        dir=2;
        if(temp2-1==0)
          {arr[i+1][j]=0;
          ans++;
          }
      }
      else if(direction[temp-1][dir]==3)
      {
        arr[i][j]=temp*10+temp2-1;
        i=i+1;
        dir=3;
        if(temp2-1==0)
          {arr[i-1][j]=0;
          ans++;
          }
      }
      
    }}
    return ans;
}
    


int main()

{
  int n,m,dir;
  int final=0;
  int e;
  cin>>n>>m;
  for(int i=0;i<n;i++)
  {
    for(int j=0;j<m;j++)
      {cin>>arr[i][j];
      temp[i][j]=arr[i][j];} //temp has backup
  }
   for(int i=0;i<n;i++)
  {
    for(int j=0;j<m;j++)
      {if(arr[i][j]==0){
        for(int k=0;k<4;k++)//direction
        {e=marble(i,j,arr,n,m,k);
        final=max(final,e);
        //restore the array
          for(int c=0;c<n;c++)
            for(int v=0;v<m;v++)
              arr[c][v]=temp[c][v];
          
        }
        
      }
        
      }
  }
 cout<<final<<endl;
 return 0;
}