#include<iostream>
using namespace std;

int t,n;
int len[3]; //message length
int disc[3]; //discount
int cust[50][2]; //0:in time, 1:end time(both inclusive)
int seq[3][3]; //announcement start,end(both inclusive), disc

//announcement seq a,b,c
void makeDiscSeq(int a, int b, int c){
	seq[0][0] = 1;
	seq[0][1] = seq[0][0] + len[a] - 1;
	seq[0][2] = disc[a];
	seq[1][0] = seq[0][1] + 1;
	seq[1][1] = seq[0][1] + len[b] - 1;
	seq[1][2] = disc[b];
	seq[2][0] = seq[1][1] + 1;
	seq[2][1] = seq[1][1] + len[c] - 1;
	seq[2][2] = disc[c];
}

int main(){
	int curr,min = 0xFFFFFF;
	cin >> t;
	for(int c = 0; c < t; c++){
		cin >> n >> len[0] >> len[1] >> len[2] >> disc[0] >> disc[1] >> disc[2];
		for(int i = 0; i < n; i++){
			cin >> cust[i][0] >> curr;
			cust[i][1] = cust[i][0] + curr - 1;
 		}
		//0-1-2
		makeDiscSeq(0,1,2);//make array of start and end times with disc
		curr = getMaxDisc();//max disc for current seq
		//0-2-1

		//1-0-2

		//1-2-0

		//2-0-1

		//2-1-0
	}
}