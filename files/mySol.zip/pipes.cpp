#include <iostream>
using namespace std;
int n, m, len, arr[50][50];
int pipes[8][4] = {{0,0,0,0}, {1,1,1,1}, {1,0,1,0}, {0,1,0,1}, {1,1,0,0}, {0,1,1,0}, {0,0,1,1}, {1,0,0,1}};

typedef struct{
	int X, Y;
}tup;

int bfsCount(int a, int b){
	if(arr[a][b] == 0)return 0;
	int visited[50][50] = {0};
	int count = 0;
	tup q[1000];
	int k = -1;
	int x, y;
	//push head
	k++;
	q[k].X = a;
	q[k].Y = b;
	count++;
	visited[a][b] = 1;
	for(int i = 0; i <=k ; i++){
		x = q[i].X;
		y = q[i].Y;
		if(visited[x][y] == len)return count;//can't go to it's children
		//check all reachable children
		//top
		if(x-1 >= 0 && arr[x-1][y] && !visited[x-1][y] && pipes[arr[x][y]][0] && pipes[arr[x-1][y]][2]){
			visited[x-1][y] = visited[x][y] + 1;
			count++;
			k++;
			q[k].X = x-1;
			q[k].Y = y;
		}
		//bottom
		if(x+1 < n && arr[x+1][y] && !visited[x+1][y] && pipes[arr[x][y]][2] && pipes[arr[x+1][y]][0]){
			visited[x+1][y] = visited[x][y] + 1;
			count++;
			k++;
			q[k].X = x+1;
			q[k].Y = y;
		}
		//right
		if(y+1 < m && arr[x][y+1] && !visited[x][y+1] && pipes[arr[x][y]][1] && pipes[arr[x][y+1]][3]){
			visited[x][y+1] = visited[x][y] + 1;
			count++;
			k++;
			q[k].X = x;
			q[k].Y = y+1;
		}
		//left
		if(y-1 >= 0 && arr[x][y-1] && !visited[x][y-1] && pipes[arr[x][y]][3] && pipes[arr[x][y-1]][1]){
			visited[x][y-1] = visited[x][y] + 1;
			count++;
			k++;
			q[k].X = x;
			q[k].Y = y-1;
		}
	}
	return count;
}

int main(){
	int t ,x, y;
	cin >> t;
	for(int c = 0; c < t; c++){
		cin >> n >> m >> x >> y >> len;
		for(int i = 0; i < n; i++){
			for(int j = 0; j < m; j++){
				cin >> arr[i][j];
			}
		}
		cout << "#" << c + 1 << " " << bfsCount(x, y) << endl;
	}

	system("pause");
	return 0;
}
