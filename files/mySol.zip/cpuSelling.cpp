#define MAX(a,b) (a>b)?(a):(b)
#include <iostream>
using namespace std;

int arr[8][4];
int cpuPrice, memPrice, N, maxCost;
int visited[8];

void getMax(int cpu, int mem, int board, int n, int cost){
    maxCost = MAX(cost+cpu*cpuPrice + mem*memPrice, maxCost);
    if(n == 4 || cpu == 0 || mem == 0 || board == 0)return;
    int i, j;
    for(int i = 0; i < N; i++){
        if(!visited[i]){
            visited[i] = 1;
            if(arr[i][0]*cpuPrice + arr[i][1]*memPrice >= arr[i][3])continue; //not feasible
            j = 1;
            while(j){
                if((j*arr[i][0] <= cpu) && (j*arr[i][1] <= mem) && (j*arr[i][2] <= board)){
                    getMax(cpu-j*arr[i][0], mem-j*arr[i][1], board-j*arr[i][2], n+1, cost + j*arr[i][3]);
                    j++;
                }
                else break;
            }
        }
        visited[i] = 0;
    }
}

int main(){
	int t, cpu, mem, board; 
	cin >> t;
	for(int c = 0; c < t; c++){		
		cin >> cpu >> mem >> board >> cpuPrice >> memPrice;
		cin >> N;
		int i, j;
		for(i = 0; i < N; i++){
			cin >> arr[i][0];//cpu
			cin >> arr[i][1];//mem
			cin >> arr[i][2];//boards
			cin >> arr[i][3];//price
		}
		maxCost = 0;
		for(int i = 0; i < N; i++)visited[i] = 0;
		getMax(cpu, mem, board, 1, 0);
		cout << c+1 << " " << maxCost << endl;
	}
	return 0;
}