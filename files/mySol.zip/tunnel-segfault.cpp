#include <iostream>
using namespace std;

int arr[15][500], dp[2][500][500], sol[15];
int c1, c2, r1, r2, m1, m2, n, h, v;
int minCost;

//computes cost of digging tunnel at level = row
int getCost(int start, int end, int last, int row){
    if(start > end)return 0;
    
    if(last!=-1){// -1 is for initial case when no excavator has been used
        if(dp[last][start][end])return dp[last][start][end];
    }
    
    int ans1, ans2;
    //use excavator 1 from start side
    if(last == 0)
        ans1 = r1 + c1*arr[row][start] + getCost(start + 1, end, 0, row);
    else
        ans1 = c1*arr[row][start] + getCost(start + 1, end, 0, row);
        
    //use excavator 2 from end side
    if(last == 1)
        ans2 = r2 + c2*arr[row][end] + getCost(start, end - 1, 1, row);
    else
        ans2 = c2*arr[row][end] + getCost(start, end - 1, 1, row);
    if(ans1 <= ans2)return dp[last][start][end] = ans1;
    return dp[last][start][end] = ans2;
}

int findCost(int row){
    if(sol[row])return sol[row];
    for(int i = 0; i < h; i++){
        for(int j = 0; j < h; j++){
            dp[0][i][j] = 0;
            dp[1][i][j] = 0;
        }
    }
    return sol[row] = getCost(0, h-1, -1, row);
}

//makes all combinations and get min by backtracking 
void getCombinations(int num, int last, int cost){
    if(num == n){
        if(cost < minCost)minCost = cost;
        return;
    }
    if(cost > minCost)return;
    int sum;//cost for next combination
    for(int i = i; i < v; i++){
        //computing cost on the fly retrieving saved cost if available
        if(num == 0 || i - last >= 2){
            if(num == 0){
                //no need to add movement cost
                sum = cost + findCost(i);
            }
            else sum = cost + findCost(i) + (m1*m1 + m2*m2)*(i-last); //movement cost added
            getCombinations(num + 1, i, sum);
        }
    }
}

int main() {
	int t;
	cin >> t;
	for(int c = 0; c < t; c++){
	    cin >> n >> h >> v;
	    cin >> c1 >> r1 >> m1;
	    cin >> c2 >> r2 >> m2;
	    for(int i = 0; i < v; i++){
	        sol[i] = 0;
	        for(int j = 0; j < h; j++){
	            cin >> arr[i][j];
	        }
	    }
	    minCost = 0xFFFFFF;
	    getCombinations(-1, 0, 0);
	    cout << minCost << endl;
	}
	return 0;
}