#include <iostream>
using namespace std;

//testcase 1
// int vertices = 9, edges=8;
// int s[]={1,1,1,2,2,7,5,3};  /* source city */
// int e[]={7,5,2,8,9,3,3,4}; /* destination/ending city*/
// int c[]={-1,-1,-1,-1,-1,-1,-1,-1,-1};

/* Test case 2 */ 

int vertices=8,edges=10;
int s[]={1,1,2,3,4,5,6,1,2,8};
int e[]={2,3,4,4,5,6,7,7,8,5};
int c[]={-1,-1,-1,-1,-1,-1,-1,-1,-1};


int main(){
    int g[1000][1000] = {0}; //adj graph
    int q[1000] = {0}; //queue
    
    //make adj matrix
    for(int i = 0; i < edges; i++){//loop over each edge
        g[s[i]-1][e[i]-1] = 1; //fwd edge
        g[e[i]-1][s[i]-1] = 1; //back edge
    }
    
    //printing graph
    for (int i=0; i< vertices; i++){
	for (int j=0; j< vertices; j++)
		cout << g[i][j];
	   cout << endl;
    }
    
    //add first vertex to queue and color it
    int k = 0; //queue tail
    c[0] = 0; //color
    q[k] = 0; //enque
    //deque one by one with i as head
    for(int i = 0; i < vertices; i++){
        //loop over head's adj vertices
        for(int j = 0; j < vertices; j++){
            if(g[q[i]][j] == 1){
                //edge exists
                if(c[j] == -1){
                    //unvisited
                    k = k + 1;
                    q[k] = j;//enque
                    if(c[q[i]] == 1)c[j] = 0;
                    else c[j] = 1; //assign opposite color
                }
                else{
                    //already visited
                    if(c[q[i]] == c[j]){//same color adj node
                        cout << "No partition exists" << endl;
                        //return 0;
                    }
                }
            }
        }
    }
    //print partition 0
    for(int i = 0; i < vertices; i++){
        if(c[i] == 0) cout << i+1;
    }
    //print partition 1 & not assigned
    cout << endl;
    for(int i = 0; i < vertices; i++){
        if(c[i]) cout << i+1;
    }
    cout << endl;
    
	return 0;
}