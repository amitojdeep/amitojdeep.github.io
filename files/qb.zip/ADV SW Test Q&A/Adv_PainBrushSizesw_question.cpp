/*#include<iostream>
#include<conio.h>

using namespace std;



int main()
{
	int grid[5][6]={{-1,-1,-1,0,-1,0},
					{1,1,1,1,-1,0},
					{1,1,1,1,-1,0},
					{-1,1,1,1,1,1},
					{-1,1,0,1,1,1}};

	int H,W;
	H=5;
	W=6;
	int lowest=1000;
	int move, move2;
	int flag, flag2;
	
	for(int i=0;i<H;i++)
	{
		for(int j=0;j<W;j++)
		{
			cout<<grid[i][j];
		}
		cout<<endl;
	}

	for(int i=0;i<H;i++)
	{
		for(int j=0;j<W;j++)
		{
			if(grid[i][j]==-1)
				continue;
			else if(grid[i][j]==0)
				continue;
			/*else if(grid[i][j] >=lowest)
				continue;
			else
			{
				//check left top
				move=1;
				while(i-move>=0 && j-move>=0 &&(grid[i][j-move]>=0 && grid[i-move][j]>=0))
				{
					move2=1;
					flag=0;
					flag2=0;
					while(i-move2>=0 && j-move2>=0 && flag==0)
					{
						if(grid[i-move2][j-move]>=0 && grid[i-move][j-move2]>=0)
						{
							move2++;
						}
						else
						{
							flag2=1;
							break;
						}
						if(move==move2-1)	//complete square is done
						{
							flag=1;
							move++;
							for(int m=i;m<=i-move;m--)
								for(int n=j;n<j-move;n--)
									grid[m][n]=move;
						}
					}
					if(flag2==1)
					{
						break;
					}

				}
				



				//check right top
				move=1;
				while(i-move>=0 && j+move<W &&(grid[i][j+move]>=0 && grid[i-move][j]>=0))
				{
					move2=1;
					flag=0;
					flag2=0;
					while(i-move2>=0 && j+move2<W && flag==0)
					{
						if(grid[i-move2][j+move]>=0 && grid[i-move][j+move2]>=0)
						{
							move2++;
						}
						else
						{
							flag2=1;
							break;
						}
						if(move==move2-1)	//complete square is done
						{
							flag=1;
							move++;
							for(int m=i;m<=i-move;m--)
								for(int n=j;n<j+move;n++)
									grid[m][n]=move;
						}
					}
					if(flag2==1)
					{
						break;
					}

				}


				//check right down
				move=1;
				while(i+move<H && j+move<W &&(grid[i][j+move]>=0 && grid[i+move][j]>=0))
				{
					move2=1;
					flag=0;
					flag2=0;
					while(i+move2<H && j+move2<W && flag==0)
					{
						if(grid[i+move2][j+move]>=0 && grid[i+move][j+move2]>=0)
						{
							move2++;
						}
						else
						{
							flag2=1;
							break;
						}
						if(move==move2-1)	//complete square is done
						{
							flag=1;
							move++;
							for(int m=i;m<=i+move;m++)
								for(int n=j;n<j+move;n++)
									grid[m][n]=move;
						}
					}
					if(flag2==1)
					{
						break;
					}

				}
				


				//check left down
				move=1;
				while(i+move<H && j-move>=0 &&(grid[i][j-move]>=0 && grid[i+move][j]>=0))
				{
					move2=1;
					flag=0;
					flag2=0;
					while(i+move2<H && j-move2>=0 && flag==0)
					{
						if(grid[i+move2][j-move]>=0 && grid[i+move][j-move2]>=0)
						{
							move2++;
						}
						else
						{
							flag2=1;
							break;
						}
						if(move==move2-1)	//complete square is done
						{
							flag=1;
							move++;
							for(int m=i;m<=i+move;m++)
								for(int n=j;n<j-move;n--)
									grid[m][n]=move;
						}
					}
					if(flag2==1)
					{
						break;
					}

				}


			}
		}
	}
	//cout<<"end";

	cout<<endl;
	for(int i=0;i<H;i++)
	{
		for(int j=0;j<W;j++)
		{
			cout<<grid[i][j];
		}
		cout<<endl;
	}

	getch();
	return 0;
}*/