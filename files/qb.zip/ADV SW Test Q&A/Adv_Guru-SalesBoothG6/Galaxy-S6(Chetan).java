import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * @author chetan.s
 * 
 */

public class booth {

	static int[][] arr;
	static int[][] copyArr;
	static boolean[][] visited;
	static int[] adjacent = new int[6];
	static int size;
	static int booths;

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
//		Scanner sc = new Scanner(System.in);
		Scanner sc = new Scanner(new FileInputStream(new File("boothImput.txt")));
		int t = sc.nextInt();
		
		for (int i = 0; i < t; i++) {
			size = sc.nextInt();
			arr = new int[size][size];
			copyArr = new int[size][size];
			visited = new boolean[size][size];
			booths = 0;
			for (int x = 0; x < size; x++) {
				for (int y = 0; y < size; y++) {
					int p = sc.nextInt();
					arr[x][y] = p;
					copyArr[x][y] = p;
				}
			}

			removeZeros();
			visited = null;
			visited = new boolean[size][size];
			System.out.println("#" + (i + 1) + " " + countBooths(0, 0));
			
		}
		sc.close();
	}

	private static int countBooths(int i, int j) {

		for (int x = 0; x < size; x++) {
			for (int y = 0; y < size; y++) {
				if (!visited[x][y]) {
					markVisited(x, y, copyArr[x][y]);
					booths++;
				}
			}
		}
		return booths;
	}

	private static void markVisited(int i, int j, int num) {
		visited[i][j] = true;
		if (i > 0 && !visited[i - 1][j] && copyArr[i - 1][j] == num) {
			markVisited(i - 1, j, num);
		}
		if (j > 0 && !visited[i][j - 1] && copyArr[i][j - 1] == num) {
			markVisited(i, j - 1, num);
		}
		if (i < size - 1 && !visited[i + 1][j] && copyArr[i + 1][j] == num) {
			markVisited(i + 1, j, num);
		}
		if (j < size - 1 && !visited[i][j + 1] && copyArr[i][j + 1] == num) {
			markVisited(i, j + 1, num);
		}

	}

	private static void removeZeros() {
		// TODO Auto-generated method stub
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < size; j++) {
				if (copyArr[i][j] == 0 && !visited[i][j]) {
					findSeqAdjacentMax(i, j);
					int max = findmax();
					replaceZerosWithMax(i, j, max);
					visited=null;
					visited = new boolean[size][size];
					adjacent = null;
					adjacent = new int[6];
				}
			}
		}
	}

	private static int findmax() {
		int max = 0;
		for (int i = 0; i < 6; i++) {
			if (adjacent[i] >= adjacent[max])
				max = i;
		}
		return max;
	}

	private static void replaceZerosWithMax(int i, int j, int num) {
		copyArr[i][j] = num;
		if (i > 0 && copyArr[i - 1][j] == 0) {
			replaceZerosWithMax(i - 1, j, num);
		}
		if (j > 0 && copyArr[i][j - 1] == 0) {
			replaceZerosWithMax(i, j - 1, num);
		}
		if (i < size - 1 && copyArr[i + 1][j] == 0) {
			replaceZerosWithMax(i + 1, j, num);
		}
		if (j < size - 1 && copyArr[i][j + 1] == 0) {
			replaceZerosWithMax(i, j + 1, num);
		}
	}

	private static void findSeqAdjacentMax(int i, int j) {
		// TODO Auto-generated method stub
		visited[i][j] = true;
		if (i > 0 && !visited[i - 1][j] && arr[i - 1][j] != 0) {
			adjacent[arr[i - 1][j]] += countSequence(i - 1, j, arr[i - 1][j]);
		} else if (i > 0 && !visited[i - 1][j] && arr[i - 1][j] == 0) {
			findSeqAdjacentMax(i - 1, j);
		}
		if (j > 0 && !visited[i][j - 1] && arr[i][j - 1] != 0) {
			adjacent[arr[i][j - 1]] += countSequence(i, j - 1, arr[i][j - 1]);
		} else if (j > 0 && !visited[i][j - 1] && arr[i][j - 1] == 0) {
			findSeqAdjacentMax(i, j - 1);
		}
		if (i < size - 1 && !visited[i + 1][j] && arr[i + 1][j] != 0) {
			adjacent[arr[i + 1][j]] += countSequence(i + 1, j, arr[i + 1][j]);
		} else if (i < size - 1 && !visited[i + 1][j] && arr[i + 1][j] == 0) {
			findSeqAdjacentMax(i + 1, j);
		}
		if (j < size - 1 && !visited[i][j + 1] && arr[i][j + 1] != 0) {
			adjacent[arr[i][j + 1]] += countSequence(i, j + 1, arr[i][j + 1]);
		} else if (j < size - 1 && !visited[i][j + 1] && arr[i][j + 1] == 0) {
			findSeqAdjacentMax(i, j + 1);
		}
	}

	private static int countSequence(int i, int j, int num) {
		visited[i][j] = true;
		int count = 1;
		if (i > 0 && !visited[i - 1][j] && arr[i - 1][j] == num) {
			count += countSequence(i - 1, j, num);
		}
		if (j > 0 && !visited[i][j - 1] && arr[i][j - 1] == num) {
			count += countSequence(i, j - 1, num);
		}
		if (i < size - 1 && !visited[i + 1][j] && arr[i + 1][j] == num) {
			count += countSequence(i + 1, j, num);
		}
		if (j < size - 1 && !visited[i][j + 1] && arr[i][j + 1] == num) {
			count += countSequence(i, j + 1, num);
		}

		return count;
	}

}
