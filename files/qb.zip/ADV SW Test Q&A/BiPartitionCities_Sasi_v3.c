#include <stdio.h>
#include <memory.h>
/* Bi partition cities is problem where the city map is represented using graph.  N no.of cities connected(vertex) randomly between each other.
We need to group the cities in two partion , where each city cannot reached each other directly.  if the given graph have conflict where you cannot partition, 
then you need to say not partionable other wise find one group and print it.  if there is a city not connected (island), then it can be added to any of the group.
Below program contains 2 sample inputs 
*/


/* Test case 1 */ 
int n=9,v=8;				/* Node and Vertices(connection in between city) in city of graph*/
int s[]={1,1,1,2,2,7,5,3};  /* source city */
int e[]={7,5,2,8,9,3,3,4};  /* ending/destination city */

int c[]={-1,-1,-1,-1,-1,-1,-1,-1,-1};   /* variable to mark the color of the city to divide it to partition 1 and 2.  
										You can call it 0 as black and 1 as white. initialized to -1 to indicate it is not visited*/



/* Test case 2 */ 
/*
int n=8,v=10;
int s[]={1,1,2,3,4,5,6,1,2,8};
int e[]={2,3,4,4,5,6,7,7,8,5};
int c[]={-1,-1,-1,-1,-1,-1,-1,-1,-1};
*/

int q[1000];		/* q- queue to maintain the cities to be visited */
int g[1000][1000];	/* graph that can hold maximum of 1000 Cities ie., N */

void main()
{

int i,j,k;
memset(g,0,1000*1000); memset(q,0,n);
c[0]=1;   /* since we are starting from 1st city..i am marking to black (0) as color */

/* Loading the vertices in to nxn graph */

for ( i=0; i < v; i++)          /* I am traversing upto v only as rest of the matrix is initialized to zero already*/
{
	g[s[i]-1][e[i]-1]= 1;
	g[e[i]-1][s[i]-1]= 1;
}


/* Just printing the populated graph is reflect the input correctly */
for (i=0; i< n; i++)
{
	for (j=0; j<n; j++)
		printf( "%d ",g[i][j]);
		
	printf("\n");
}


/* LOGIC BEGINS */

k=0;
q[k]=1-1;    /* since starting from city one... the logic mark the queue with 1st city. due to indexsation, it is 1 - 1*/

for ( i=0; i<n; i++)
{
	for (j=0 ;j<n; j++)                                    /* traversing the matrix ie., cities*/
	{
		//printf("[%d][%d] ",q[i],j);
		
		if( g[q[i]][j] == 1 )      //if vertices exist? i mean connection is there between city i and j
		{

			if ( c[j]== -1 )       // if color of city j (desitination city) is -1, then no one visited the city
			{
				k=k+1;							// incrementing the index for queue
				q[k]=j;  printf(" %d ",j+1);	// just adding next city into queue where the path has to further explore

				if( c[q[i]]==1 )				// checking the ORGINATING CITY I is 1(white) or 0(black), so that the connecting city will have OPP value 1 or 0 
							c[j]=0;				// if orginating city is 1 , the connecting city is black(zero).
				else
							c[j]=1;				// if orginating city is 1 , the connecting city is white(1).
			}
			else if ( c[q[i]] == c[j] )			// if city is visited already, then cross verify the orginated(city I) and destinatin(city J) having same color. It is conflict and group cannot be made
				printf("\nGrouping not possible=-1\n");
		}
	} printf("\n");
		
}


/* printing the cities that are marked as white.. */ 

for (i=0;i<n;i++)
	if (c[i]==1) printf("%d ",i+1);



	getchar();

}


