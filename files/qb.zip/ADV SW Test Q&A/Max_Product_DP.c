/*Kids are given N stickers. They get candies in exchange for stickers.
//To maximize the no. of candies the kids got, a plan was made such that group of kids 
//would be divided into groups. The product of the members in each group would be the 
//no of candies the kids got in return.
// For eg: 10 stickers and 3 groups of kids can be divided as 1 1 8 = 10
or 3 3 4 = 10.
But 1*1*8 = 8
2*2*4 = 36.
So output is 36
*/

#include<stdio.h>
long arr[101][101] = { 0, };
long max = 0;

int main()
{
	int N = 0, G = 0, i, j, k;
	int val = 0;

	scanf("%d %d", &N, &G);
	arr[1][1] = 1;

	for (k = 1; k <= 100; k++)
	{
		arr[k][1] = k;
		for (j = 2; j <= 100; j++)
		{
			max = 0;
			for (i = 1; i < k; i++)
			{
				val = arr[i][1] * arr[k - i][j - 1];
				if (val> max)
				{
					max = val;
				}
			}
			arr[k][j] = max;
		}
	}
	printf("\n");
	 //to print
	for (i = 1; i <= 10; i++)
	{
	for (j = 1; j <= 10; j++)
	printf("%d \t",arr[i][j]);
	printf("\n");
	}
	
	printf("\n Answer = %d", arr[N][G]);
}