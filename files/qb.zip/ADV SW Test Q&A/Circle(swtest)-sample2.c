#include <stdio.h>
//answer 56
int r1=4, r2=2;
int IsSqrInside (int x, int y);
int IsSqrOutside (int x, int y);
int main()
{

    int ValidSquareR1_inside=0, ValidSquareR2_outside=0, TotalValidSqr=0;
    int i,j,x,y;

    printf("calculate valid square in R1 first Quadrant\n");
    //calculate valid square in R1 first Quadrant

    for (x=0; x <r1; x++)
    {
        for(y=0; y< r1;y++)
        {
            if ( IsSqrInside(x,y) == 1)
            {
                ValidSquareR1_inside++;
            }
        }
    } 

    //calculate for 4 quadrant
    ValidSquareR1_inside = ValidSquareR1_inside * 4;
    printf("ValidSquareR1_inside=%d\n", ValidSquareR1_inside);

    printf("calculate valid square in R2 first Quadrant\n");
    //calculate valid square in R2 first Quadrant
    for (x=0; x<r2; x++)
    {
        for(y=0; y<r2;y++)
        {
            if ( IsSqrOutside(x,y) == 1)
            {
                ValidSquareR2_outside++;
            }
        }
    } 

    //calculate for 4 quadrant
    ValidSquareR2_outside = ValidSquareR2_outside * 4;
    printf("ValidSquareR2_outside=%d\n", ValidSquareR2_outside);


    TotalValidSqr = ValidSquareR1_inside + ValidSquareR2_outside - ( (r2*2)*(r2*2) );

    printf("Hello, World! %d\n", TotalValidSqr);

    return 0;
}

int IsSqrInside (int x, int y)
{
    int x1=x, y1=y,  x2=x+1, y2=y, x3=x+1, y3=y+1,  x4=x, y4=y1+1;

    if ( (x1*x1)+(y1*y1) <= r1*r1 && (x2*x2)+(y3*y3) <= r1*r1 && (x3*x3)+(y3*y3) <= r1*r1 && (x4*x4)+(y4*y4) <= r1*r1 )
            return 1;
    else
            return 0;

}

int IsSqrOutside (int x, int y)
{
    int x1=x, y1=y,  x2=x+1, y2=y, x3=x+1, y3=y+1,  x4=x, y4=y1+1;

    if ( (x1*x1)+(y1*y1) >= r2*r2 && (x2*x2)+(y3*y3) >= r2*r2 && (x3*x3)+(y3*y3) >= r2*r2 && (x4*x4)+(y4*y4) >= r2*r2 )
            return 1;
    else
            return 0;

}
