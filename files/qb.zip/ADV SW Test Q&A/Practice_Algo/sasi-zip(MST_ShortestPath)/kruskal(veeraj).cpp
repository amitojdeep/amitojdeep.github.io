#include <iostream>
#include <algorithm>
#include <iterator>

const int MX = 1000;

struct Edge { int u, v, w; } edge[MX*MX];
int N, M, parent[MX];

int find(int i) { while (parent[i]) i = parent[i]; return i; }
void my_union(int i, int j) { parent[i] = j; }

int main()
{
	scanf("%d%d", &N, &M);
	for (int i = 0; i < M; ++i) 
		scanf("%d%d%d", &edge[i].u, &edge[i].v, &edge[i].w);
	std::sort(edge, edge+M, [](const Edge &e1, const Edge &e2) {
		return e1.w < e2.w;
	});
	int cost = 0;
	for (int i = 0; i < M; ++i)
	{
		int u = find(edge[i].u), v = find(edge[i].v);
		if (u != v) 
		{
			my_union(u, v);
			cost += edge[i].w;
		}
	}
	printf("%d\n", cost);
	return 0;
}