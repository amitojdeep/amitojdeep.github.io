#include <iostream>

const int MX = 1000;
const int INF = 10007;

struct Pair { int v, w; };

Pair adj[MX][MX];
int N, M, n[MX], c[MX], nq, visited[MX];

int main()
{
	int u, v, w;
	scanf("%d%d", &N, &M);
	for (int i = 0; i < M; ++i)
	{
		scanf("%d%d%d", &u, &v, &w);
		--u; --v;
		adj[u][n[u]].v = v;
		adj[u][n[u]++].w = w;
		adj[v][n[v]].v = u;
		adj[v][n[v]++].w = w;
	}
	for (int i = 0; i < N; ++i)
		c[i] = INF;
	nq = N;
	int cost = 0;
	while (nq--)
	{
		int min = (INF + 1), uz;
		for (int i = 0; i < N; ++i)
			if (!visited[i] && c[i] < min)
			{
				min = c[i];
				u = i;
			}
		if (min < INF) cost += min;
		visited[u] = 1;
		for (int i = 0; i < n[u]; ++i)
		{
			Pair p = adj[u][i];
			if (!visited[p.v] && p.w < c[p.v])
				c[p.v] = p.w;		
		}
	}
	printf("%d\n", cost);
	return 0;
}