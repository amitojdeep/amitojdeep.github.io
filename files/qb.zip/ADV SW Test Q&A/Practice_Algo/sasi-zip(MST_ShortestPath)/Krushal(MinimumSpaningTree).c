/***********************************************************
* You can use all the programs on  www.c-program-example.com
* for personal and learning purposes. For permissions to use the
* programs for commercial purposes,
* contact info@c-program-example.com
* To find more C programs, do visit www.c-program-example.com
* and browse!
*
*         MINIMIUM SPANING TREE - KRUSKAL ALGORITHM
*                      Happy Coding
***********************************************************/
 
#include<stdio.h>
//#include<conio.h>
//#include<stdlib.h>
int i,j,k,a,b,u,v,n,ne=1;
int min,mincost=0,cost[10][10],parent[10];
int find(int);
int uni(int,int);
printparent();
 main()
{
 //clrscr();
 freopen("Kruskal_input.txt","r",stdin);
 printf("\n\n\tImplementation of Kruskal's algorithm\n\n");
 printf("\nEnter the no. of vertices\n");
 scanf("%d",&n);
 printf("\nEnter the cost adjacency matrix\n");
 for(i=1;i<=n;i++)
 {
  for(j=1;j<=n;j++)
  {
   scanf("%d",&cost[i][j]);
   if(cost[i][j]==0)
    cost[i][j]=999;
  }
 }
 printf("\nThe edges of Minimum Cost Spanning Tree are\n\n");
 while(ne<n)
 {
  for(i=1,min=999;i<=n;i++)
  {
   for(j=1;j<=n;j++)
   {
    if(cost[i][j]<min)
    {
     min=cost[i][j];
     a=u=i;
     b=v=j;
    }
   }
  }
  printf("\nfind u=%d v=%d ",u,v); printparent();
  u=find(u);  
  v=find(v);
  printf("\nfind u=%d v=%d ",u,v); 
  
  if(uni(u,v))
  {
   printf("\n%d edge (%d,%d) =%d   ",ne++,a,b,min);
   mincost +=min;
  }
  printparent();printf("\n");
  
  cost[a][b]=cost[b][a]=999;
 }
 printf("\n\tMinimum cost = %d\n",mincost);
 getch();
}


int find(int i)
{
printf(" ->");
 while(parent[i])
 {
   i=parent[i]; printf("parent[%d] ", i);}
 return i;
}
int uni(int i,int j)
{
 if(i!=j)
 {
  parent[j]=i;
  return 1;
 }
 return 0;
}

printparent()
{ int i;
	printf("p[");
	for (i=1; i<= n;i++) printf("%d ",parent[i]);
	printf("]");
}

/* below input and output (9 is vertices)
9 
0	4	0	0	0	0	0	8	0
4	0	8	0	0	0	0	11	0
0	8	0	7	0	4	0	0	2
0	0	7	0	9	14	0	0	0
0	0	0	9	0	10	0	0	0
0	0	4	14	10	0	2	0	0
0	0	0	0	0	2	0	1	6
8	11	0	0	0	0	1	0	7
0	0	2	0	0	0	6	7	0

37 is output
*/
