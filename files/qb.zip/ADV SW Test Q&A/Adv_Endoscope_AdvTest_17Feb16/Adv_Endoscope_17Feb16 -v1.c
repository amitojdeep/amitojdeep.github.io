/* Endoscope Advance Test on 16 Feb 2016 by Sasikumar */
#include <stdio.h>

#define myprintf //printf   
#define UP R-1
#define DOWN R+1
#define LEFT C-1
#define RIGHT C+1
#define SameROW R
#define SameCOL C
//#define OR(CurrCell,P1,P2,P4,P7) (CurrCell==P1 || vmat[R]C]==2 || vmat[R]C]==4 || vmat[R]C]==7 ) 
#define OR(CurrCell,P1,P2,P3, P4) (CurrCell==P1 || CurrCell==P2 || CurrCell==P3 || CurrCell==P4 ) 

int N=0, M=0, R=0, C=0, L=0;
int Matrix[51][51]={0,};
int vmat[51][51]={0,};	//visited matrix
int T=0, Answer=0;
int tc_idx, i,j;

int DFS(int R, int C, int L);
int printmatrix();
int clearmatrix();
main()
{
	scanf("%d", &T);
	
	for( tc_idx = 0; tc_idx < T; tc_idx++)
	{
		scanf("%d", &N);
		scanf("%d", &M);
		scanf("%d", &R);
		scanf("%d", &C);
		scanf("%d", &L);		
		
		myprintf("NxM=%dx%d, (R,C)=(%d,%d) , Endoscope Length=%d\n",N, M,R,C,L);
		
		if ( N < 5 || N >=50 ||  M < 5 || M >=50 || R < 0 || R > N-1 || C < 0 || C > M-1  )
			Answer = 0;
		else if ( L == 0)
			Answer = 0;
//		else
//		{
			for(i=0;i<N;i++)
				for(j=0;j<M;j++)
					scanf("%d", &Matrix[i][j]);
			printmatrix();
			
			if (Matrix[R][C]==0)
				Answer =0;
			else 
				DFS(R, C, L);
//		}
		 	
		printf("\n#%d %d\n", tc_idx+1, Answer);
		clearmatrix();
	}
}

DFS (int R, int C, int L)
{
	if (L==0)
		return;
	
	if (!vmat[R][C])
	{
		vmat[R][C]=1;
		Answer++;
		myprintf("Matrix[%d][%d]=%d  - ",R, C, Matrix[R][C]);
	}
	else
		return;
	
	if ( OR(Matrix[R][C],1,2,4,7) &&  OR(Matrix[UP][C],1,2,5,6) && UP >=0 ) DFS(UP, SameCOL, L-1);
	if ( OR(Matrix[R][C],1,2,5,6) &&  OR(Matrix[DOWN][C],1,2,4,7) && DOWN <51 ) DFS(DOWN,SameCOL, L-1);
	if ( OR(Matrix[R][C],1,3,6,7) &&  OR(Matrix[R][LEFT],1,3,4,5) && LEFT >=0 ) DFS(SameROW,LEFT, L-1);
	if ( OR(Matrix[R][C],1,3,4,5) &&  OR(Matrix[R][RIGHT],1,3,6,7) && RIGHT <51 ) DFS(SameROW,RIGHT, L-1);	
}

printmatrix()
{
	int x, y;
	for(x=0;x<N;x++)
	{
		for(y=0;y<M;y++)
			myprintf("%d ", Matrix[x][y]);
		myprintf("\n");
	}
}

clearmatrix()
{
	int x, y;
	for(x=0;x<N;x++)
		for(y=0;y<M;y++)
			Matrix[x][y]=vmat[x][y]=0;
	Answer=0;
}
