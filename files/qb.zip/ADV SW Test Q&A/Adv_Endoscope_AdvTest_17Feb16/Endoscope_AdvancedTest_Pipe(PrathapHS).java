import java.util.Scanner;

public class Pipe {
	static int up[] = { 0, 1, 1, 0, 1, 0, 0, 1 };
	static int down[] = { 0, 1, 1, 0, 0, 1, 1, 0 }; 
	static int left[] = { 0, 1, 0, 1, 0, 0, 1, 1 };
	static int right[] = { 0, 1, 0, 1, 1, 1, 0, 0 };
	static int N;	static int M;	static int X;	static int Y;	static int D;	
	static int mat[][] = new int[55][55];	static int vmat[][] = new int[55][55];	static int dist[][] = new int[55][55];	
	
	static Queue queue = new Queue();
	
	static void visit(int x1, int y1, int x2, int y2){
		dist[x2][y2] = dist[x1][y1] + 1;
		vmat[x2][y2] = 1;
		queue.push(new Node(x2,y2));
	}
	
	static void bfs(int ex,int ey){
		visit(ex,ey,ex,ey);
		while(!queue.empty()){
			Node p = queue.pop();
			int x = p.x, y = p.y;
			if(x-1 >= 0 && up[mat[x][y]] == 1 && down[mat[x-1][y]]==1 && vmat[x-1][y]==0){
				visit(x,y,x-1,y);
			}
			if(x+1 < N  && down[mat[x][y]] == 1 && up[mat[x+1][y]]==1 && vmat[x+1][y]==0){
				visit(x,y,x+1,y);
			}
			if(y-1 >= 0 && left[mat[x][y]] == 1 && right[mat[x][y-1]]==1 && vmat[x][y-1]==0){
				visit(x,y,x,y-1);
			}
			if(y+1 < M && right[mat[x][y]] == 1 && left[mat[x][y+1]]==1 && vmat[x][y+1]==0){
				visit(x,y,x,y+1);
			}
		}
	}
	
	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		N = in.nextInt();M = in.nextInt();X = in.nextInt();Y = in.nextInt();D = in.nextInt();
		for (int i = 0; i < N; ++i) 
			for (int j = 0; j < M; ++j) {
				mat[i][j] = in.nextInt();
			}
		bfs(X,Y);
		int cnt = 0;
		for(int i=0;i<N;i++)
			for(int j=0;j<M;j++){
				if(dist[i][j] != 0 && dist[i][j] <= D)
					++cnt;
			}
		System.out.println(cnt);
		in.close();
	}

}
class Queue{
	int f;	int r;
	Node Q[]=new Node[55*55];
	void push(Node node){
		Q[r++] = node;
	}
	Node pop(){
		return Q[f++];
	}
	boolean empty(){
		return f==r;
	}
}

class Node{
	int x;
	int y;
	Node(){
		x=0;y=0;
	}
	Node(int x,int y){
		this.x=x;
		this.y=y;
	}
}
